﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ArmGenerate : MonoBehaviour {
    public GameObject armForThisPos;
    private GameObject bossBody;
    private bool bossInDanger;
    public float timeGen;
    private float timeGenCounter;
	// Use this for initialization
	void Start () {
        timeGenCounter = timeGen;
	}

    // Update is called once per frame
    void Update()
    {
        if (timeGenCounter > 0) {
            timeGenCounter -= Time.deltaTime;
        }
        else {
            Instantiate(armForThisPos, transform.position, transform.rotation);
            timeGenCounter = timeGen;
        }
    }
}
